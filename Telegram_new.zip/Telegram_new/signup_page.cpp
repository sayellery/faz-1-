#include "signup_page.h"
#include "ui_signup_page.h"
#include "start_page.h"
#include "verify_page.h"
#include "globals.h"

#include "QMessageBox"
#include "QIntValidator"
#include "ctime"
#include <QSqlDatabase>
#include <QtSql>
#include <MyLib/Newfolder/MyLib.h>


int captcha_code;                                          // متغیر بررسی کد کپچا
QString NewUserName ;                                      // متغیر برای دریافت و ذخیره یوزرنیم
QString NewPassword ;                                      // متغیر برای دریافت و ذخیره پسورد
MyQSqlDatabase db ;

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

signup_page::signup_page(QWidget *parent) :
    QMainWindow(parent)
    , ui(new Ui::signup_page)

{
    ui->setupUi(this);
    ui->captcha_line->setValidator(new QIntValidator());   // ورودی لاین کپچا فقط اینتیجر باشه
    ui->tabWidget->setCurrentIndex(0);                     // پیش فرض تب ثبت نام نمایش داده شود
    ui->pass_btn1->setStyleSheet("border-image: url(:/Image/images/Show pass.jpg);") ; // پیش فرض آیکون (شو پسورد) نمایش داده شود
    ui->pass_btn2->setStyleSheet("border-image: url(:/Image/images/Show pass.jpg);") ; // پیش فرض آیکون (شو پسورد) نمایش داده شود
    signup_page::on_captcha_btn_clicked();
    if(tm==0)                                              // تم روشن
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(255, 255, 255);");
    }
    if(tm==1)                                              // تم دارک
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(120, 120, 120);");
    }
    if(lng==0)                                             // زبان انگلیسی
    {
        ui->user_line1->setPlaceholderText("Username");
        ui->user_line2->setPlaceholderText("Username");
        ui->user_line1->setToolTip("Username must contain only letters,numbers and underscore, and be between 4 to 20 characters long.");
        ui->user_line2->setToolTip("Username must contain only letters,numbers and underscore, and be between 4 to 20 characters long.");
        ui->pass_line1->setPlaceholderText("Password");
        ui->pass_line2->setPlaceholderText("Password");
        ui->pass_line1->setToolTip("Password must contain only numbers and (! @ # $ * _ ), and be between 4 to 8 characters long.");
        ui->pass_line2->setToolTip("password must contain only numbers and (! @ # $ * _ ), and be between 4 to 8 characters long.");
        ui->captcha_line->setPlaceholderText("Captcha Code");
        ui->signup_btn->setText("Sign up");
        ui->login_btn->setText("Log in");
        ui->tab_btn1->setText("have an account?");
        ui->tab_btn2->setText("dont have an account?");
        ui->tabWidget->setTabText(0 , "Sign up");
        ui->tabWidget->setTabText(1 , "Log in");
        ui->back_btn->setText("Back");
    }
    if(lng==1)                                             // زبان فارسی
    {
        ui->user_line1->setPlaceholderText("نام کاربری");
        ui->user_line2->setPlaceholderText("نام کاربری");
        ui->user_line1->setToolTip("باید شامل حروف ، اعداد ، یا خط تیره باشد و بین 4 تا 20 کاراکتر باشد");
        ui->user_line2->setToolTip("باید شامل حروف ، اعداد ، یا خط تیره باشد و بین 4 تا 20 کاراکتر باشد");
        ui->pass_line1->setPlaceholderText("رمز عبور");
        ui->pass_line2->setPlaceholderText("رمز عبور");
        ui->pass_line1->setToolTip("رمز عبور باید شامل اعداد یا (! @ # $ * _ ) باشد و بین 4 تا 8 کاراکتر باشد");
        ui->pass_line2->setToolTip("رمز عبور باید شامل اعداد یا (! @ # $ * _ ) باشد و بین 4 تا 8 کاراکتر باشد");
        ui->captcha_line->setPlaceholderText("کد کپچا");
        ui->signup_btn->setText("ثبت نام");
        ui->login_btn->setText("ورود");
        ui->tab_btn1->setText("حساب کاربری دارید؟ (ثبت نام)");
        ui->tab_btn2->setText("(ورود) حساب کاربری ندارید؟");
        ui->tabWidget->setTabText(0 , "ثبت نام");
        ui->tabWidget->setTabText(1 , "ورود");
        ui->back_btn->setText("عقب");
    }
}



// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

signup_page::~signup_page()
{
    delete ui;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void signup_page::on_captcha_btn_clicked()                 //تولید کپچا
{
    srand(time(0));                                                                   // تولید عدد رندوم با تابع زمان
    captcha_code = rand()%9000+1000;                                                  // مقدار دهی متغیر کپچا کد در بازه 4 رقمی
    ui->captcha_txt->setText(QString::number(captcha_code));                          // نمایش کد کپچا
}

void signup_page::on_tab_btn1_clicked()                    // نمایش تب ورود
{
    ui->tabWidget->setCurrentIndex(1);
}

void signup_page::on_tab_btn2_clicked()                    // نمایش تب ثبت نام
{
    ui->tabWidget->setCurrentIndex(0);
}

void signup_page::on_back_btn_clicked()                    // بازگشت به صفحه قبلی و بستن صفحه فعلی
{   start_page *start = new start_page;
    start->show() ;
    signup_page::close();
}

bool signup_page::user_shart(QString username)             // الگوی مناسب برای یوزرنیم
{
    QRegExp username_ex("^[a-zA-Z0-9_]{4,20}$");           // الگوی قابل قبول برای یوزرنیم
    if (username_ex.exactMatch(username))
    {return 1;}
    else
    {return 0;}
}

bool signup_page::pass_shart(QString password)             // الگوی مناسب برای پسورد
{
    QRegExp password_ex("^[0-9!@#$*_]{4,8}$");             // الگوی قابل قبول برای پسورد
    if (password_ex.exactMatch(password))
    {return 1;}
    else
    {return 0;}
}

void signup_page::on_pass_btn1_clicked()                   // دکمه مخفی کردن پسورد در تب ثبت نام
{
    static bool index = false ;

    if ( index )
    {
        ui->pass_btn1->setStyleSheet("border-image: url(:/Image/images/Show pass.jpg);") ;
        ui->pass_line1->setEchoMode(QLineEdit::Password) ;
        index = false ;
    }
    else
    {
        ui->pass_btn1->setStyleSheet("border-image: url(:/Image/images/Hide pass.jpg);") ;
        ui->pass_line1->setEchoMode(QLineEdit::Normal) ;
        index = true ;
    }
    return ;
}

void signup_page::on_pass_btn2_clicked()                   // دکمه مخفی کردن پسورد در تب ورود
{
    static bool index = false ;

    if ( index )
    {
        ui->pass_btn2->setStyleSheet("border-image: url(:/Image/images/Show pass.jpg);") ;
        ui->pass_line2->setEchoMode(QLineEdit::Password) ;
        index = false ;
    }
    else
    {
        ui->pass_btn2->setStyleSheet("border-image: url(:/Image/images/Hide pass.jpg);") ;
        ui->pass_line2->setEchoMode(QLineEdit::Normal) ;
        index = true ;
    }
    return ;
}

void signup_page::on_signup_btn_clicked()                  // ثبت نام
{
    bool Check_Existing_Username = db.Search( ui->user_line1->text() , username ) ;  // متغیری برای جلوگیری از یوزرنیم تکراری

    if ( ui->user_line1->text() == "" )                    // خطا برای خالی بودن یوزرنیم
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"نام کاربری را وارد کنید" , "باشه") : QMessageBox::information(this ,"" ,"Enter the username" , "OK");
    }
    else if (!user_shart(ui->user_line1->text()))          // خطا برای مناسب نبودن یوزرنیم
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"نام کاربری را اصلاح کنید" , "باشه") : QMessageBox::information(this ,"" ,"Correct the username" , "OK");
    }
    else if (ui->pass_line1->text() == "")                 // خطا برای خالی بودن پسورد
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"رمز عبور را وارد کنید" , "باشه") : QMessageBox::information(this ,"" ,"Enter the password" , "OK");
    }
    else if (!pass_shart(ui->pass_line1->text()) )         // خطا برای مناسب نبودن پسورد
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"رمز عبور را اصلاح کنید" , "باشه") : QMessageBox::information(this ,"" ,"Correct the password" , "OK");
    }
    else if ( ui->captcha_line->text() != QString::number(captcha_code) )   // خطا برای اشتباه بودن کپچا
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"کد کپچا را اصلاح کنید" , "باشه") : QMessageBox::information(this ,"" ,"Correct the captcha code" , "OK");
        signup_page::on_captcha_btn_clicked();
    }
    else                                                   // حالت بدون خطا
        {
        if (Check_Existing_Username)                       //  حالتی که یوزرنیم تکراری است و ثبت نام نمی شود
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"نام کاربری تکراری است" , "باشه") : QMessageBox::information(this ,"" ,"Username already exists" , "OK");
    }
        else                                               // حالتی که یوزرنیم جدید است و ثبت نام می شود
    {
        NewUserName = ui->user_line1->text() ;             // مقدار دهی و ثبت یوزرنیم جدید
        NewPassword = ui->pass_line1->text() ;             // مقدار دهی و ثبت پسورد جدید
        (lng == 1) ? QMessageBox::information(this ," " ,"ثبت نام موفق!" , "باشه") : QMessageBox::information(this ,"" ,"Successful signup" , "OK");

        verify_page *verify = new verify_page;
        verify->show() ;
        this->~signup_page() ;
    }
        }

}

void signup_page::on_login_btn_clicked()                   // ورود
{

    if ( ui->user_line2->text() == "" )                    // خطا برای خالی بودن یوزرنیم
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"نام کاربری را وارد کنید" , "باشه") : QMessageBox::information(this ,"" ,"Enter the username" , "OK");
    }
    else if (!user_shart(ui->user_line2->text()))          // خطا برای مناسب نبودن یوزرنیم
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"نام کاربری را اصلاح کنید" , "باشه") : QMessageBox::information(this ,"" ,"Correct the username" , "OK");
    }
    else if (ui->pass_line2->text() == "")                 // خطا برای خالی بودن پسورد
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"رمز عبور را وارد کنید" , "باشه") : QMessageBox::information(this ,"" ,"Enter the password" , "OK");
    }
    else if (!pass_shart(ui->pass_line2->text()) )         // خطا برای مناسب نبودن پسورد
    {
        (lng == 1) ? QMessageBox::information(this ," " ,"رمز عبور را اصلاح کنید" , "باشه") : QMessageBox::information(this ,"" ,"Correct the password" , "OK");
    }
    else                                                   // حالت بدون خطا
    {
        if ( db.Search( ui->user_line2->text() , username ) )// حالتی که کاربر قبلا ثبت نام کرده و موجوده
            {
                if ( db.GetInfo( ui->user_line2->text() , username , password ).toString() != ui->pass_line2->text() )
                {
                    (lng == 1) ? QMessageBox::information(this ," " ,"رمز عبور یا نام کاربری اشتباه است" , "باشه") : QMessageBox::information(this ,"" ,"Password or Username is incorrect" , "OK");
                }
                else                                       // حالتی که مشکلی نیست و کاربر وارد می شود
                {
                    NewUserName = ui->user_line2->text() ;
                    NewPassword = ui->pass_line2->text() ;
                    verify_page *verify = new verify_page ;
                    verify->show() ;
                    this->~signup_page() ;
                }
            }
        else                                               // حالتی که کاربر ثبت نام نکرده و موجود نیست
        {(lng == 1) ? QMessageBox::information(this ," " ," کاربر پیدا نشد" , "باشه") : QMessageBox::information(this ,"" ,"User not found" , "OK");}
    }
}
