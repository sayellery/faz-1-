#include "client.h"

Client::Client(QObject *parent) : QObject(parent)
{
    socket = new QTcpSocket(this);

    connect(socket, SIGNAL(connected()), this, SIGNAL(connected()));
    connect(socket, SIGNAL(disconnected()), this, SIGNAL(disconnected()));
    connect(socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SIGNAL(error(QAbstractSocket::SocketError)));
    connect(socket, SIGNAL(readyRead()), this, SLOT(receiveMessage()));
}

void Client::connectToServer(QString ipAddress, int port)
{
    socket->connectToHost(ipAddress, port);
}

void Client::disconnectFromServer()
{
    socket->disconnectFromHost();
}

void Client::sendMessage(QString message)
{
    socket->write(message.toUtf8());
    socket->flush();
}

void Client::receiveMessage()
{
    QByteArray data = socket->readAll();
    QString message(data);

    qDebug() << "Received message:" << message;

    emit messageReceived(message);
}
