#ifndef ADD_CONTACT_PAGE_H
#define ADD_CONTACT_PAGE_H

#include <QMainWindow>

namespace Ui {
class add_contact_page;
}

class add_contact_page : public QMainWindow
{
    Q_OBJECT

public:
    explicit add_contact_page(QWidget *parent = nullptr);
    ~add_contact_page();

private slots:
    void on_add_btn_clicked();

private:
    Ui::add_contact_page *ui;
};

#endif // ADD_CONTACT_PAGE_H
