#include "start_page.h"
#include "chat_page.h"
#include <QCoreApplication>
#include <QApplication>

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool lng;        // متغیر گلوبال برای زبان برنامه
bool tm;         // متغیر گلوبال برای تم برنامه

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   start_page start;
   start.show();
   chat_page chat;
    //chat.show();
    return a.exec();
}
