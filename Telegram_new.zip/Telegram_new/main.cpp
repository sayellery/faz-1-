#include "start_page.h"
#include <QCoreApplication>
#include <QApplication>

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool lng;                                                  // متغیر گلوبال برای زبان برنامه
bool tm;                                                   // متغیر گلوبال برای تم برنامه
QString global_username;                                   // متغیر گلوبال برای ارتباط بین صفحات با یوزرنیم کاربر

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   start_page start;
   start.show();
    return a.exec();
}
