#include "add_contact_page.h"
#include "ui_add_contact_page.h"
#include "globals.h"
#include "chat_page.h"

#include <QSqlDatabase>
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"

add_contact_page::add_contact_page(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::add_contact_page)
{
    ui->setupUi(this);
    QSqlDatabase db ;
    db= QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\user_info.db");
    db.open();
}

add_contact_page::~add_contact_page()
{
    delete ui;
}

void add_contact_page::on_add_btn_clicked()
{
    QString username = ui->user_line->text();
    QSqlQuery q;
    q.exec("SELECT username FROM user WHERE username= '"+username+"' ");
    if(q.first())
    {
        q.exec("UPDATE contact SET");
    }
}
