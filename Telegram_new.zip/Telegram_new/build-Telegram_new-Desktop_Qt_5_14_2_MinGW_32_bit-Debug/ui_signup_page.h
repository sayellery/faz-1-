/********************************************************************************
** Form generated from reading UI file 'signup_page.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIGNUP_PAGE_H
#define UI_SIGNUP_PAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_signup_page
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QTabWidget *tabWidget;
    QWidget *signup_tab;
    QGridLayout *gridLayout_3;
    QGroupBox *signup_box;
    QLineEdit *user_line1;
    QLineEdit *captcha_txt;
    QLineEdit *captcha_line;
    QLineEdit *pass_line1;
    QPushButton *captcha_btn;
    QPushButton *signup_btn;
    QPushButton *tab_btn1;
    QPushButton *pass_btn1;
    QWidget *login_tab;
    QGridLayout *gridLayout_2;
    QGroupBox *login_box;
    QLineEdit *user_line2;
    QLineEdit *pass_line2;
    QPushButton *login_btn;
    QPushButton *tab_btn2;
    QPushButton *pass_btn2;
    QPushButton *back_btn;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *signup_page)
    {
        if (signup_page->objectName().isEmpty())
            signup_page->setObjectName(QString::fromUtf8("signup_page"));
        signup_page->resize(800, 600);
        signup_page->setMinimumSize(QSize(800, 600));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Image/images/telegram logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        signup_page->setWindowIcon(icon);
        signup_page->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(signup_page);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 0, 3, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(80, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 0, 4, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 1, 1, 1);

        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setMinimumSize(QSize(304, 400));
        tabWidget->setMaximumSize(QSize(304, 400));
        QFont font;
        font.setPointSize(8);
        tabWidget->setFont(font);
        tabWidget->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/day mode backgroung.png);\n"
""));
        tabWidget->setTabPosition(QTabWidget::South);
        tabWidget->setTabShape(QTabWidget::Triangular);
        tabWidget->setUsesScrollButtons(true);
        tabWidget->setDocumentMode(false);
        tabWidget->setTabsClosable(false);
        tabWidget->setMovable(false);
        tabWidget->setTabBarAutoHide(false);
        signup_tab = new QWidget();
        signup_tab->setObjectName(QString::fromUtf8("signup_tab"));
        gridLayout_3 = new QGridLayout(signup_tab);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        signup_box = new QGroupBox(signup_tab);
        signup_box->setObjectName(QString::fromUtf8("signup_box"));
        signup_box->setMinimumSize(QSize(280, 360));
        signup_box->setMaximumSize(QSize(280, 360));
        QFont font1;
        font1.setPointSize(9);
        signup_box->setFont(font1);
        signup_box->setStyleSheet(QString::fromUtf8(""));
        user_line1 = new QLineEdit(signup_box);
        user_line1->setObjectName(QString::fromUtf8("user_line1"));
        user_line1->setEnabled(true);
        user_line1->setGeometry(QRect(45, 20, 190, 30));
        user_line1->setMinimumSize(QSize(190, 30));
        user_line1->setMaximumSize(QSize(190, 30));
        user_line1->setFocusPolicy(Qt::ClickFocus);
        user_line1->setStyleSheet(QString::fromUtf8("\n"
"border-image: url(:/Image/images/white.png);"));
        user_line1->setMaxLength(20);
        user_line1->setAlignment(Qt::AlignCenter);
        user_line1->setClearButtonEnabled(true);
        captcha_txt = new QLineEdit(signup_box);
        captcha_txt->setObjectName(QString::fromUtf8("captcha_txt"));
        captcha_txt->setEnabled(false);
        captcha_txt->setGeometry(QRect(45, 170, 190, 30));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Wide Latin"));
        font2.setPointSize(22);
        font2.setBold(false);
        font2.setItalic(false);
        font2.setUnderline(false);
        font2.setWeight(50);
        font2.setStrikeOut(false);
        font2.setStyleStrategy(QFont::PreferAntialias);
        captcha_txt->setFont(font2);
        captcha_txt->setCursor(QCursor(Qt::ArrowCursor));
        captcha_txt->setFocusPolicy(Qt::NoFocus);
        captcha_txt->setAutoFillBackground(false);
        captcha_txt->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/captcha background1.png);\n"
"font: 22pt \"Wide Latin\";\n"
"color: rgb(255, 0, 0);"));
        captcha_txt->setInputMethodHints(Qt::ImhNone);
        captcha_txt->setFrame(true);
        captcha_txt->setAlignment(Qt::AlignCenter);
        captcha_txt->setDragEnabled(true);
        captcha_txt->setReadOnly(true);
        captcha_txt->setClearButtonEnabled(false);
        captcha_line = new QLineEdit(signup_box);
        captcha_line->setObjectName(QString::fromUtf8("captcha_line"));
        captcha_line->setGeometry(QRect(45, 120, 190, 30));
        captcha_line->setFocusPolicy(Qt::ClickFocus);
        captcha_line->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        captcha_line->setMaxLength(4);
        captcha_line->setAlignment(Qt::AlignCenter);
        captcha_line->setReadOnly(false);
        captcha_line->setClearButtonEnabled(true);
        pass_line1 = new QLineEdit(signup_box);
        pass_line1->setObjectName(QString::fromUtf8("pass_line1"));
        pass_line1->setGeometry(QRect(45, 70, 190, 30));
        pass_line1->setMinimumSize(QSize(190, 30));
        pass_line1->setMaximumSize(QSize(190, 30));
        pass_line1->setFocusPolicy(Qt::ClickFocus);
        pass_line1->setStyleSheet(QString::fromUtf8("\n"
"border-image: url(:/Image/images/white.png);"));
        pass_line1->setMaxLength(8);
        pass_line1->setFrame(true);
        pass_line1->setEchoMode(QLineEdit::Password);
        pass_line1->setAlignment(Qt::AlignCenter);
        pass_line1->setClearButtonEnabled(true);
        captcha_btn = new QPushButton(signup_box);
        captcha_btn->setObjectName(QString::fromUtf8("captcha_btn"));
        captcha_btn->setGeometry(QRect(205, 169, 30, 30));
        captcha_btn->setFocusPolicy(Qt::ClickFocus);
        captcha_btn->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Image/images/Reload.png"), QSize(), QIcon::Normal, QIcon::Off);
        captcha_btn->setIcon(icon1);
        captcha_btn->setIconSize(QSize(27, 25));
        captcha_btn->setFlat(true);
        signup_btn = new QPushButton(signup_box);
        signup_btn->setObjectName(QString::fromUtf8("signup_btn"));
        signup_btn->setGeometry(QRect(70, 270, 140, 30));
        QFont font3;
        font3.setPointSize(10);
        font3.setBold(true);
        font3.setItalic(false);
        font3.setUnderline(false);
        font3.setWeight(75);
        signup_btn->setFont(font3);
        signup_btn->setFocusPolicy(Qt::ClickFocus);
        signup_btn->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);\n"
"color: rgb(36, 136, 255);"));
        signup_btn->setIcon(icon);
        signup_btn->setAutoDefault(false);
        signup_btn->setFlat(true);
        tab_btn1 = new QPushButton(signup_box);
        tab_btn1->setObjectName(QString::fromUtf8("tab_btn1"));
        tab_btn1->setGeometry(QRect(70, 310, 140, 30));
        QFont font4;
        font4.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font4.setPointSize(7);
        font4.setBold(true);
        font4.setWeight(75);
        tab_btn1->setFont(font4);
        tab_btn1->setFocusPolicy(Qt::ClickFocus);
        tab_btn1->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        tab_btn1->setFlat(true);
        pass_btn1 = new QPushButton(signup_box);
        pass_btn1->setObjectName(QString::fromUtf8("pass_btn1"));
        pass_btn1->setGeometry(QRect(200, 70, 30, 30));
        pass_btn1->setFocusPolicy(Qt::ClickFocus);
        pass_btn1->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        pass_btn1->setIconSize(QSize(25, 25));
        pass_btn1->setAutoDefault(false);
        pass_btn1->setFlat(true);

        gridLayout_3->addWidget(signup_box, 0, 0, 1, 1);

        tabWidget->addTab(signup_tab, QString());
        login_tab = new QWidget();
        login_tab->setObjectName(QString::fromUtf8("login_tab"));
        gridLayout_2 = new QGridLayout(login_tab);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        login_box = new QGroupBox(login_tab);
        login_box->setObjectName(QString::fromUtf8("login_box"));
        login_box->setEnabled(true);
        login_box->setMinimumSize(QSize(280, 260));
        login_box->setMaximumSize(QSize(270, 260));
        login_box->setStyleSheet(QString::fromUtf8(""));
        user_line2 = new QLineEdit(login_box);
        user_line2->setObjectName(QString::fromUtf8("user_line2"));
        user_line2->setGeometry(QRect(45, 20, 190, 30));
        user_line2->setFocusPolicy(Qt::ClickFocus);
        user_line2->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);\n"
""));
        user_line2->setMaxLength(20);
        user_line2->setAlignment(Qt::AlignCenter);
        user_line2->setClearButtonEnabled(true);
        pass_line2 = new QLineEdit(login_box);
        pass_line2->setObjectName(QString::fromUtf8("pass_line2"));
        pass_line2->setGeometry(QRect(45, 70, 190, 30));
        pass_line2->setMinimumSize(QSize(190, 30));
        pass_line2->setMaximumSize(QSize(190, 30));
        pass_line2->setFocusPolicy(Qt::ClickFocus);
        pass_line2->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        pass_line2->setMaxLength(8);
        pass_line2->setFrame(true);
        pass_line2->setEchoMode(QLineEdit::Password);
        pass_line2->setAlignment(Qt::AlignCenter);
        pass_line2->setClearButtonEnabled(true);
        login_btn = new QPushButton(login_box);
        login_btn->setObjectName(QString::fromUtf8("login_btn"));
        login_btn->setGeometry(QRect(70, 170, 140, 30));
        login_btn->setFont(font3);
        login_btn->setFocusPolicy(Qt::ClickFocus);
        login_btn->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);\n"
"\n"
""));
        login_btn->setIcon(icon);
        login_btn->setFlat(true);
        tab_btn2 = new QPushButton(login_box);
        tab_btn2->setObjectName(QString::fromUtf8("tab_btn2"));
        tab_btn2->setGeometry(QRect(70, 210, 140, 30));
        tab_btn2->setFont(font4);
        tab_btn2->setFocusPolicy(Qt::ClickFocus);
        tab_btn2->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        tab_btn2->setFlat(true);
        pass_btn2 = new QPushButton(login_box);
        pass_btn2->setObjectName(QString::fromUtf8("pass_btn2"));
        pass_btn2->setGeometry(QRect(200, 70, 30, 30));
        pass_btn2->setFocusPolicy(Qt::ClickFocus);
        pass_btn2->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        pass_btn2->setIconSize(QSize(25, 25));
        pass_btn2->setAutoDefault(false);
        pass_btn2->setFlat(true);

        gridLayout_2->addWidget(login_box, 0, 0, 1, 1);

        tabWidget->addTab(login_tab, QString());

        gridLayout->addWidget(tabWidget, 0, 2, 1, 1);

        back_btn = new QPushButton(centralwidget);
        back_btn->setObjectName(QString::fromUtf8("back_btn"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(back_btn->sizePolicy().hasHeightForWidth());
        back_btn->setSizePolicy(sizePolicy);
        back_btn->setMinimumSize(QSize(80, 30));
        back_btn->setMaximumSize(QSize(80, 30));
        back_btn->setFocusPolicy(Qt::ClickFocus);
        back_btn->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Image/images/Back icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        back_btn->setIcon(icon2);
        back_btn->setFlat(true);

        gridLayout->addWidget(back_btn, 0, 0, 1, 1);

        signup_page->setCentralWidget(centralwidget);
        menubar = new QMenuBar(signup_page);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        signup_page->setMenuBar(menubar);
        statusbar = new QStatusBar(signup_page);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        signup_page->setStatusBar(statusbar);

        retranslateUi(signup_page);

        tabWidget->setCurrentIndex(1);
        captcha_btn->setDefault(false);
        signup_btn->setDefault(true);
        tab_btn1->setDefault(true);
        pass_btn1->setDefault(false);
        login_btn->setDefault(true);
        tab_btn2->setDefault(true);
        pass_btn2->setDefault(false);
        back_btn->setDefault(true);


        QMetaObject::connectSlotsByName(signup_page);
    } // setupUi

    void retranslateUi(QMainWindow *signup_page)
    {
        signup_page->setWindowTitle(QCoreApplication::translate("signup_page", "Telegram", nullptr));
        signup_box->setTitle(QString());
#if QT_CONFIG(tooltip)
        user_line1->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        user_line1->setText(QString());
        user_line1->setPlaceholderText(QString());
#if QT_CONFIG(tooltip)
        captcha_txt->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        captcha_txt->setWhatsThis(QString());
#endif // QT_CONFIG(whatsthis)
#if QT_CONFIG(accessibility)
        captcha_txt->setAccessibleDescription(QString());
#endif // QT_CONFIG(accessibility)
        captcha_txt->setText(QString());
        captcha_txt->setPlaceholderText(QString());
#if QT_CONFIG(tooltip)
        captcha_line->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        captcha_line->setText(QString());
        captcha_line->setPlaceholderText(QString());
#if QT_CONFIG(tooltip)
        pass_line1->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        pass_line1->setInputMask(QString());
        pass_line1->setText(QString());
        pass_line1->setPlaceholderText(QString());
#if QT_CONFIG(tooltip)
        captcha_btn->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        captcha_btn->setText(QString());
#if QT_CONFIG(tooltip)
        signup_btn->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        signup_btn->setText(QString());
#if QT_CONFIG(tooltip)
        tab_btn1->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        tab_btn1->setText(QString());
#if QT_CONFIG(tooltip)
        pass_btn1->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        pass_btn1->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(signup_tab), QString());
        login_box->setTitle(QString());
#if QT_CONFIG(tooltip)
        user_line2->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        user_line2->setText(QString());
        user_line2->setPlaceholderText(QString());
#if QT_CONFIG(tooltip)
        pass_line2->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        pass_line2->setInputMask(QString());
        pass_line2->setText(QString());
        pass_line2->setPlaceholderText(QString());
#if QT_CONFIG(tooltip)
        login_btn->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        login_btn->setText(QString());
#if QT_CONFIG(tooltip)
        tab_btn2->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        tab_btn2->setText(QString());
#if QT_CONFIG(tooltip)
        pass_btn2->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        pass_btn2->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(login_tab), QString());
#if QT_CONFIG(tooltip)
        back_btn->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        back_btn->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class signup_page: public Ui_signup_page {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIGNUP_PAGE_H
