/********************************************************************************
** Form generated from reading UI file 'name_page.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NAME_PAGE_H
#define UI_NAME_PAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_name_page
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer;
    QGroupBox *name_Box;
    QLineEdit *name_line;
    QPushButton *name_btn;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *back_btn;
    QSpacerItem *horizontalSpacer_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *name_page)
    {
        if (name_page->objectName().isEmpty())
            name_page->setObjectName(QString::fromUtf8("name_page"));
        name_page->resize(800, 600);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Image/images/telegram logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        name_page->setWindowIcon(icon);
        centralwidget = new QWidget(name_page);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 1, 1, 1);

        name_Box = new QGroupBox(centralwidget);
        name_Box->setObjectName(QString::fromUtf8("name_Box"));
        name_Box->setMinimumSize(QSize(270, 160));
        name_Box->setMaximumSize(QSize(270, 160));
        name_Box->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/day mode backgroung.png);"));
        name_line = new QLineEdit(name_Box);
        name_line->setObjectName(QString::fromUtf8("name_line"));
        name_line->setGeometry(QRect(40, 30, 190, 30));
        name_line->setMouseTracking(true);
        name_line->setTabletTracking(false);
        name_line->setFocusPolicy(Qt::ClickFocus);
        name_line->setAcceptDrops(true);
        name_line->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        name_line->setMaxLength(4);
        name_line->setAlignment(Qt::AlignCenter);
        name_line->setClearButtonEnabled(true);
        name_btn = new QPushButton(name_Box);
        name_btn->setObjectName(QString::fromUtf8("name_btn"));
        name_btn->setEnabled(true);
        name_btn->setGeometry(QRect(85, 90, 100, 30));
        QFont font;
        font.setPointSize(10);
        font.setBold(true);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(75);
        name_btn->setFont(font);
        name_btn->setFocusPolicy(Qt::ClickFocus);
        name_btn->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);\n"
"color: rgb(36, 136, 255);"));
        name_btn->setIcon(icon);
        name_btn->setFlat(true);

        gridLayout->addWidget(name_Box, 0, 2, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 0, 3, 1, 1);

        back_btn = new QPushButton(centralwidget);
        back_btn->setObjectName(QString::fromUtf8("back_btn"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(back_btn->sizePolicy().hasHeightForWidth());
        back_btn->setSizePolicy(sizePolicy);
        back_btn->setMinimumSize(QSize(80, 30));
        back_btn->setMaximumSize(QSize(80, 30));
        back_btn->setFocusPolicy(Qt::ClickFocus);
        back_btn->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Image/images/Back icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        back_btn->setIcon(icon1);
        back_btn->setFlat(true);

        gridLayout->addWidget(back_btn, 0, 0, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(80, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 0, 4, 1, 1);

        name_page->setCentralWidget(centralwidget);
        menubar = new QMenuBar(name_page);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        name_page->setMenuBar(menubar);
        statusbar = new QStatusBar(name_page);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        name_page->setStatusBar(statusbar);

        retranslateUi(name_page);

        name_btn->setDefault(true);
        back_btn->setDefault(true);


        QMetaObject::connectSlotsByName(name_page);
    } // setupUi

    void retranslateUi(QMainWindow *name_page)
    {
        name_page->setWindowTitle(QCoreApplication::translate("name_page", "Telegram", nullptr));
        name_Box->setTitle(QString());
#if QT_CONFIG(tooltip)
        name_line->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        name_line->setPlaceholderText(QCoreApplication::translate("name_page", "Enter Your Name", nullptr));
#if QT_CONFIG(tooltip)
        name_btn->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        name_btn->setText(QString());
#if QT_CONFIG(tooltip)
        back_btn->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        back_btn->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class name_page: public Ui_name_page {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NAME_PAGE_H
