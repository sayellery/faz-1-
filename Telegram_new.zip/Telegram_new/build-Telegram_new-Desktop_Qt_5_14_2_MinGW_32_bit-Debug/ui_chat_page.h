/********************************************************************************
** Form generated from reading UI file 'chat_page.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHAT_PAGE_H
#define UI_CHAT_PAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_chat_page
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer;
    QFrame *frame_2;
    QPushButton *pushButton_3;
    QListWidget *listWidget;
    QPushButton *pushButton_4;
    QFrame *frame;
    QLabel *label;
    QTextEdit *textEdit;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QListWidget *listWidget_2;
    QSpacerItem *horizontalSpacer_2;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *chat_page)
    {
        if (chat_page->objectName().isEmpty())
            chat_page->setObjectName(QString::fromUtf8("chat_page"));
        chat_page->resize(800, 600);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Image/images/telegram logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        chat_page->setWindowIcon(icon);
        centralwidget = new QWidget(chat_page);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 0, 1, 1);

        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setMinimumSize(QSize(200, 500));
        frame_2->setMaximumSize(QSize(200, 500));
        frame_2->setStyleSheet(QString::fromUtf8("background-color: rgb(213, 213, 213);"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        pushButton_3 = new QPushButton(frame_2);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(100, 470, 100, 30));
        pushButton_3->setMinimumSize(QSize(100, 30));
        pushButton_3->setMaximumSize(QSize(100, 30));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: rgb(222, 255, 222);"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Image/images/add contact.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_3->setIcon(icon1);
        pushButton_3->setFlat(false);
        listWidget = new QListWidget(frame_2);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(0, 0, 200, 470));
        listWidget->setMinimumSize(QSize(200, 470));
        listWidget->setMaximumSize(QSize(200, 470));
        pushButton_4 = new QPushButton(frame_2);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(0, 470, 100, 30));
        pushButton_4->setMinimumSize(QSize(100, 30));
        pushButton_4->setMaximumSize(QSize(100, 30));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(222, 255, 222);\n"
""));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Image/images/setting.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_4->setIcon(icon2);
        pushButton_4->setFlat(false);

        gridLayout->addWidget(frame_2, 0, 1, 1, 1);

        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setMinimumSize(QSize(550, 500));
        frame->setMaximumSize(QSize(550, 500));
        frame->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(213, 213, 213);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setEnabled(false);
        label->setGeometry(QRect(0, 0, 550, 50));
        label->setMinimumSize(QSize(550, 50));
        label->setMaximumSize(QSize(550, 50));
        QFont font;
        font.setFamily(QString::fromUtf8("MS UI Gothic"));
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        textEdit = new QTextEdit(frame);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(30, 470, 490, 30));
        textEdit->setMinimumSize(QSize(490, 30));
        textEdit->setMaximumSize(QSize(490, 16777215));
        textEdit->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        pushButton = new QPushButton(frame);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(0, 470, 30, 30));
        pushButton->setMinimumSize(QSize(30, 30));
        pushButton->setMaximumSize(QSize(30, 30));
        pushButton->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/Image/images/paper clip.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon3);
        pushButton->setIconSize(QSize(25, 25));
        pushButton->setFlat(false);
        pushButton_2 = new QPushButton(frame);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(520, 470, 30, 30));
        pushButton_2->setMinimumSize(QSize(30, 30));
        pushButton_2->setMaximumSize(QSize(30, 30));
        pushButton_2->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/Image/images/send message.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_2->setIcon(icon4);
        pushButton_2->setFlat(false);
        listWidget_2 = new QListWidget(frame);
        listWidget_2->setObjectName(QString::fromUtf8("listWidget_2"));
        listWidget_2->setGeometry(QRect(0, 50, 550, 420));
        listWidget_2->setMinimumSize(QSize(550, 420));
        listWidget_2->setMaximumSize(QSize(200, 420));
        listWidget_2->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/day mode backgroung.png);"));

        gridLayout->addWidget(frame, 0, 2, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_2, 0, 1, 1, 1);

        chat_page->setCentralWidget(centralwidget);
        menubar = new QMenuBar(chat_page);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        chat_page->setMenuBar(menubar);
        statusbar = new QStatusBar(chat_page);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        chat_page->setStatusBar(statusbar);

        retranslateUi(chat_page);

        pushButton_3->setDefault(false);
        pushButton_4->setDefault(false);
        pushButton->setDefault(false);
        pushButton_2->setDefault(false);


        QMetaObject::connectSlotsByName(chat_page);
    } // setupUi

    void retranslateUi(QMainWindow *chat_page)
    {
        chat_page->setWindowTitle(QCoreApplication::translate("chat_page", "Telegram", nullptr));
        pushButton_3->setText(QCoreApplication::translate("chat_page", "Add Contact", nullptr));
        pushButton_4->setText(QCoreApplication::translate("chat_page", "Setting", nullptr));
        label->setText(QCoreApplication::translate("chat_page", "   name", nullptr));
        textEdit->setPlaceholderText(QCoreApplication::translate("chat_page", "Message...", nullptr));
        pushButton->setText(QString());
        pushButton_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class chat_page: public Ui_chat_page {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHAT_PAGE_H
