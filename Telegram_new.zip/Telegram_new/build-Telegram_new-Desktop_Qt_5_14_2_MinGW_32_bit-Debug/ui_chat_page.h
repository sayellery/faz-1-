/********************************************************************************
** Form generated from reading UI file 'chat_page.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHAT_PAGE_H
#define UI_CHAT_PAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_chat_page
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QFrame *frame;
    QLabel *pv_name;
    QTextEdit *messege_line;
    QPushButton *file_btn;
    QPushButton *send_btn;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_3;
    QSpacerItem *verticalSpacer;
    QSpacerItem *verticalSpacer_2;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer;
    QToolBox *toolBox;
    QWidget *page1;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *user_box;
    QLineEdit *user_edit_line;
    QPushButton *user_btn;
    QGroupBox *name_box;
    QLineEdit *name_edit_line;
    QPushButton *name_btn;
    QGroupBox *pass_box;
    QLineEdit *pass_edit_line;
    QPushButton *pass_btn;
    QComboBox *light_combo;
    QComboBox *language_combo;
    QPushButton *delete_btn;
    QWidget *page_2;
    QScrollArea *scrollArea_2;
    QWidget *scrollAreaWidgetContents_2;
    QVBoxLayout *verticalLayout;
    QGroupBox *add_contact_box;
    QPushButton *contact_btn;
    QLineEdit *contact_line;
    QSpacerItem *verticalSpacer_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *chat_page)
    {
        if (chat_page->objectName().isEmpty())
            chat_page->setObjectName(QString::fromUtf8("chat_page"));
        chat_page->resize(800, 600);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Image/images/telegram logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        chat_page->setWindowIcon(icon);
        centralwidget = new QWidget(chat_page);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setMinimumSize(QSize(550, 500));
        frame->setMaximumSize(QSize(550, 500));
        frame->setStyleSheet(QString::fromUtf8("\n"
"background-color: rgb(213, 213, 213);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        pv_name = new QLabel(frame);
        pv_name->setObjectName(QString::fromUtf8("pv_name"));
        pv_name->setEnabled(false);
        pv_name->setGeometry(QRect(0, 0, 550, 60));
        pv_name->setMinimumSize(QSize(550, 60));
        pv_name->setMaximumSize(QSize(550, 60));
        QFont font;
        font.setFamily(QString::fromUtf8("MS UI Gothic"));
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        pv_name->setFont(font);
        pv_name->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        messege_line = new QTextEdit(frame);
        messege_line->setObjectName(QString::fromUtf8("messege_line"));
        messege_line->setGeometry(QRect(30, 470, 490, 30));
        messege_line->setMinimumSize(QSize(490, 30));
        messege_line->setMaximumSize(QSize(490, 16777215));
        messege_line->viewport()->setProperty("cursor", QVariant(QCursor(Qt::IBeamCursor)));
        messege_line->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        file_btn = new QPushButton(frame);
        file_btn->setObjectName(QString::fromUtf8("file_btn"));
        file_btn->setGeometry(QRect(0, 470, 30, 30));
        file_btn->setMinimumSize(QSize(30, 30));
        file_btn->setMaximumSize(QSize(30, 30));
        file_btn->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Image/images/paper clip.png"), QSize(), QIcon::Normal, QIcon::Off);
        file_btn->setIcon(icon1);
        file_btn->setIconSize(QSize(25, 25));
        file_btn->setFlat(false);
        send_btn = new QPushButton(frame);
        send_btn->setObjectName(QString::fromUtf8("send_btn"));
        send_btn->setGeometry(QRect(520, 470, 30, 30));
        send_btn->setMinimumSize(QSize(30, 30));
        send_btn->setMaximumSize(QSize(30, 30));
        send_btn->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/white.png);"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Image/images/send message.png"), QSize(), QIcon::Normal, QIcon::Off);
        send_btn->setIcon(icon2);
        send_btn->setFlat(false);
        scrollArea = new QScrollArea(frame);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setGeometry(QRect(0, 60, 550, 410));
        scrollArea->setMinimumSize(QSize(550, 410));
        scrollArea->setMaximumSize(QSize(550, 410));
        scrollArea->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/day mode backgroung.png);"));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 548, 408));
        verticalLayout_3 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout->addWidget(frame, 0, 2, 1, 1);


        gridLayout_2->addLayout(gridLayout, 1, 2, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer, 0, 2, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer_2, 2, 2, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_2, 1, 3, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 1, 0, 1, 1);

        toolBox = new QToolBox(centralwidget);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        toolBox->setMinimumSize(QSize(200, 500));
        toolBox->setMaximumSize(QSize(200, 500));
        toolBox->setFrameShape(QFrame::NoFrame);
        page1 = new QWidget();
        page1->setObjectName(QString::fromUtf8("page1"));
        page1->setGeometry(QRect(0, 0, 200, 440));
        verticalLayout_2 = new QVBoxLayout(page1);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        user_box = new QGroupBox(page1);
        user_box->setObjectName(QString::fromUtf8("user_box"));
        user_box->setMaximumSize(QSize(180, 40));
        user_edit_line = new QLineEdit(user_box);
        user_edit_line->setObjectName(QString::fromUtf8("user_edit_line"));
        user_edit_line->setGeometry(QRect(0, 10, 150, 20));
        user_edit_line->setFocusPolicy(Qt::ClickFocus);
        user_edit_line->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);\n"
""));
        user_edit_line->setClearButtonEnabled(false);
        user_btn = new QPushButton(user_box);
        user_btn->setObjectName(QString::fromUtf8("user_btn"));
        user_btn->setGeometry(QRect(150, 10, 20, 20));
        user_btn->setMinimumSize(QSize(20, 20));
        user_btn->setMaximumSize(QSize(20, 20));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/Image/images/confirm.png"), QSize(), QIcon::Normal, QIcon::Off);
        user_btn->setIcon(icon3);

        verticalLayout_2->addWidget(user_box);

        name_box = new QGroupBox(page1);
        name_box->setObjectName(QString::fromUtf8("name_box"));
        name_box->setMaximumSize(QSize(180, 40));
        name_edit_line = new QLineEdit(name_box);
        name_edit_line->setObjectName(QString::fromUtf8("name_edit_line"));
        name_edit_line->setGeometry(QRect(0, 10, 150, 20));
        name_edit_line->setFocusPolicy(Qt::ClickFocus);
        name_edit_line->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);"));
        name_edit_line->setClearButtonEnabled(false);
        name_btn = new QPushButton(name_box);
        name_btn->setObjectName(QString::fromUtf8("name_btn"));
        name_btn->setGeometry(QRect(150, 10, 20, 20));
        name_btn->setMinimumSize(QSize(20, 20));
        name_btn->setMaximumSize(QSize(20, 20));
        name_btn->setIcon(icon3);

        verticalLayout_2->addWidget(name_box);

        pass_box = new QGroupBox(page1);
        pass_box->setObjectName(QString::fromUtf8("pass_box"));
        pass_box->setMaximumSize(QSize(180, 40));
        pass_edit_line = new QLineEdit(pass_box);
        pass_edit_line->setObjectName(QString::fromUtf8("pass_edit_line"));
        pass_edit_line->setGeometry(QRect(0, 10, 150, 20));
        pass_edit_line->setFocusPolicy(Qt::ClickFocus);
        pass_edit_line->setStyleSheet(QString::fromUtf8("background-image: url(:/Image/images/white.png);\n"
""));
        pass_edit_line->setClearButtonEnabled(false);
        pass_btn = new QPushButton(pass_box);
        pass_btn->setObjectName(QString::fromUtf8("pass_btn"));
        pass_btn->setGeometry(QRect(150, 10, 20, 20));
        pass_btn->setMinimumSize(QSize(20, 20));
        pass_btn->setMaximumSize(QSize(20, 20));
        pass_btn->setIcon(icon3);

        verticalLayout_2->addWidget(pass_box);

        light_combo = new QComboBox(page1);
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/Image/images/Light mode.png"), QSize(), QIcon::Normal, QIcon::Off);
        light_combo->addItem(icon4, QString());
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/Image/images/Dark mode.png"), QSize(), QIcon::Normal, QIcon::Off);
        light_combo->addItem(icon5, QString());
        light_combo->setObjectName(QString::fromUtf8("light_combo"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(light_combo->sizePolicy().hasHeightForWidth());
        light_combo->setSizePolicy(sizePolicy);
        light_combo->setMinimumSize(QSize(100, 25));
        light_combo->setMaximumSize(QSize(80, 25));
        light_combo->setFocusPolicy(Qt::ClickFocus);
        light_combo->setStyleSheet(QString::fromUtf8("background-color: rgb(225, 225, 225);"));
        light_combo->setFrame(false);

        verticalLayout_2->addWidget(light_combo);

        language_combo = new QComboBox(page1);
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/Image/images/English icon.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        language_combo->addItem(icon6, QString());
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/Image/images/persian icon.jfif"), QSize(), QIcon::Normal, QIcon::Off);
        language_combo->addItem(icon7, QString());
        language_combo->setObjectName(QString::fromUtf8("language_combo"));
        sizePolicy.setHeightForWidth(language_combo->sizePolicy().hasHeightForWidth());
        language_combo->setSizePolicy(sizePolicy);
        language_combo->setMinimumSize(QSize(100, 25));
        language_combo->setMaximumSize(QSize(80, 25));
        language_combo->setFocusPolicy(Qt::ClickFocus);
        language_combo->setStyleSheet(QString::fromUtf8("background-color: rgb(225, 225, 225);"));
        language_combo->setFrame(false);

        verticalLayout_2->addWidget(language_combo);

        delete_btn = new QPushButton(page1);
        delete_btn->setObjectName(QString::fromUtf8("delete_btn"));
        QFont font1;
        font1.setBold(true);
        font1.setWeight(75);
        delete_btn->setFont(font1);
        delete_btn->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 0);"));

        verticalLayout_2->addWidget(delete_btn);

        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/Image/images/setting.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolBox->addItem(page1, icon8, QString::fromUtf8(""));
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        page_2->setGeometry(QRect(0, 0, 200, 440));
        scrollArea_2 = new QScrollArea(page_2);
        scrollArea_2->setObjectName(QString::fromUtf8("scrollArea_2"));
        scrollArea_2->setGeometry(QRect(0, 0, 200, 440));
        scrollArea_2->setMinimumSize(QSize(200, 440));
        scrollArea_2->setMaximumSize(QSize(200, 440));
        scrollArea_2->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 198, 438));
        verticalLayout = new QVBoxLayout(scrollAreaWidgetContents_2);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        add_contact_box = new QGroupBox(scrollAreaWidgetContents_2);
        add_contact_box->setObjectName(QString::fromUtf8("add_contact_box"));
        add_contact_box->setMinimumSize(QSize(180, 50));
        add_contact_box->setMaximumSize(QSize(180, 16777215));
        contact_btn = new QPushButton(add_contact_box);
        contact_btn->setObjectName(QString::fromUtf8("contact_btn"));
        contact_btn->setGeometry(QRect(140, 10, 30, 30));
        contact_btn->setMinimumSize(QSize(30, 30));
        contact_btn->setMaximumSize(QSize(30, 30));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/Image/images/add contact.png"), QSize(), QIcon::Normal, QIcon::Off);
        contact_btn->setIcon(icon9);
        contact_btn->setAutoDefault(false);
        contact_btn->setFlat(false);
        contact_line = new QLineEdit(add_contact_box);
        contact_line->setObjectName(QString::fromUtf8("contact_line"));
        contact_line->setGeometry(QRect(10, 10, 130, 30));
        contact_line->setMinimumSize(QSize(130, 30));
        contact_line->setMaximumSize(QSize(130, 30));

        verticalLayout->addWidget(add_contact_box);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);

        scrollArea_2->setWidget(scrollAreaWidgetContents_2);
        toolBox->addItem(page_2, icon9, QString::fromUtf8(""));

        gridLayout_2->addWidget(toolBox, 1, 1, 1, 1);

        chat_page->setCentralWidget(centralwidget);
        menubar = new QMenuBar(chat_page);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        chat_page->setMenuBar(menubar);
        statusbar = new QStatusBar(chat_page);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        chat_page->setStatusBar(statusbar);

        retranslateUi(chat_page);

        file_btn->setDefault(false);
        send_btn->setDefault(false);
        toolBox->setCurrentIndex(1);
        user_btn->setDefault(true);
        name_btn->setDefault(true);
        pass_btn->setDefault(true);
        light_combo->setCurrentIndex(0);
        language_combo->setCurrentIndex(0);
        contact_btn->setDefault(true);


        QMetaObject::connectSlotsByName(chat_page);
    } // setupUi

    void retranslateUi(QMainWindow *chat_page)
    {
        chat_page->setWindowTitle(QCoreApplication::translate("chat_page", "Telegram", nullptr));
        pv_name->setText(QCoreApplication::translate("chat_page", "Name", nullptr));
        messege_line->setPlaceholderText(QCoreApplication::translate("chat_page", "Message...", nullptr));
        file_btn->setText(QString());
        send_btn->setText(QString());
        user_box->setTitle(QString());
        user_edit_line->setPlaceholderText(QString());
        user_btn->setText(QString());
        name_box->setTitle(QString());
        name_edit_line->setPlaceholderText(QString());
        name_btn->setText(QString());
        pass_box->setTitle(QString());
        pass_edit_line->setPlaceholderText(QString());
        pass_btn->setText(QString());
        light_combo->setItemText(0, QString());
        light_combo->setItemText(1, QString());

        language_combo->setItemText(0, QString());
        language_combo->setItemText(1, QString());

        delete_btn->setText(QString());
        toolBox->setItemText(toolBox->indexOf(page1), QString());
        add_contact_box->setTitle(QString());
        contact_btn->setText(QString());
        toolBox->setItemText(toolBox->indexOf(page_2), QString());
    } // retranslateUi

};

namespace Ui {
    class chat_page: public Ui_chat_page {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHAT_PAGE_H
