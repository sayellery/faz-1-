/********************************************************************************
** Form generated from reading UI file 'start_page.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_START_PAGE_H
#define UI_START_PAGE_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_start_page
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QLabel *caption_lbl;
    QLabel *start_pic_lbl;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *option_box;
    QGridLayout *gridLayout_2;
    QComboBox *light_combo;
    QComboBox *language_combo;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer_4;
    QSpacerItem *horizontalSpacer_3;
    QSpacerItem *horizontalSpacer_5;
    QLabel *welcome_lbl;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *start_btn;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *start_page)
    {
        if (start_page->objectName().isEmpty())
            start_page->setObjectName(QString::fromUtf8("start_page"));
        start_page->setEnabled(true);
        start_page->resize(800, 600);
        start_page->setMinimumSize(QSize(800, 600));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Image/images/telegram logo.png"), QSize(), QIcon::Normal, QIcon::Off);
        start_page->setWindowIcon(icon);
        start_page->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(start_page);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        caption_lbl = new QLabel(centralwidget);
        caption_lbl->setObjectName(QString::fromUtf8("caption_lbl"));
        caption_lbl->setMinimumSize(QSize(200, 30));
        caption_lbl->setMaximumSize(QSize(200, 30));
        QFont font;
        font.setStyleStrategy(QFont::PreferAntialias);
        caption_lbl->setFont(font);
        caption_lbl->setInputMethodHints(Qt::ImhNone);
        caption_lbl->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(caption_lbl, 3, 3, 1, 1);

        start_pic_lbl = new QLabel(centralwidget);
        start_pic_lbl->setObjectName(QString::fromUtf8("start_pic_lbl"));
        start_pic_lbl->setMinimumSize(QSize(0, 200));
        start_pic_lbl->setMaximumSize(QSize(16777215, 200));
        start_pic_lbl->setStyleSheet(QString::fromUtf8("border-image: url(:/Image/images/Start Messaging.png);\n"
""));

        gridLayout->addWidget(start_pic_lbl, 0, 0, 1, 5);

        verticalSpacer_2 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 8, 3, 1, 1);

        option_box = new QGroupBox(centralwidget);
        option_box->setObjectName(QString::fromUtf8("option_box"));
        option_box->setMinimumSize(QSize(240, 50));
        option_box->setMaximumSize(QSize(240, 50));
        option_box->setLayoutDirection(Qt::LeftToRight);
        option_box->setTitle(QString::fromUtf8(""));
        option_box->setAlignment(Qt::AlignBottom|Qt::AlignRight|Qt::AlignTrailing);
        option_box->setFlat(false);
        option_box->setCheckable(false);
        option_box->setChecked(false);
        gridLayout_2 = new QGridLayout(option_box);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        light_combo = new QComboBox(option_box);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Image/images/Light mode.png"), QSize(), QIcon::Normal, QIcon::Off);
        light_combo->addItem(icon1, QString());
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Image/images/Dark mode.png"), QSize(), QIcon::Normal, QIcon::Off);
        light_combo->addItem(icon2, QString());
        light_combo->setObjectName(QString::fromUtf8("light_combo"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(light_combo->sizePolicy().hasHeightForWidth());
        light_combo->setSizePolicy(sizePolicy);
        light_combo->setMinimumSize(QSize(100, 25));
        light_combo->setMaximumSize(QSize(80, 25));
        light_combo->setFocusPolicy(Qt::ClickFocus);
        light_combo->setStyleSheet(QString::fromUtf8("background-color: rgb(225, 225, 225);"));
        light_combo->setFrame(false);

        gridLayout_2->addWidget(light_combo, 1, 1, 1, 1);

        language_combo = new QComboBox(option_box);
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/Image/images/English icon.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        language_combo->addItem(icon3, QString());
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/Image/images/persian icon.jfif"), QSize(), QIcon::Normal, QIcon::Off);
        language_combo->addItem(icon4, QString());
        language_combo->setObjectName(QString::fromUtf8("language_combo"));
        sizePolicy.setHeightForWidth(language_combo->sizePolicy().hasHeightForWidth());
        language_combo->setSizePolicy(sizePolicy);
        language_combo->setMinimumSize(QSize(100, 25));
        language_combo->setMaximumSize(QSize(80, 25));
        language_combo->setFocusPolicy(Qt::ClickFocus);
        language_combo->setStyleSheet(QString::fromUtf8("background-color: rgb(225, 225, 225);"));
        language_combo->setFrame(false);

        gridLayout_2->addWidget(language_combo, 1, 0, 1, 1);


        gridLayout->addWidget(option_box, 8, 4, 1, 1, Qt::AlignRight|Qt::AlignBottom);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_6, 3, 4, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 4, 3, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_4, 1, 4, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 1, 1, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_5, 3, 1, 1, 1);

        welcome_lbl = new QLabel(centralwidget);
        welcome_lbl->setObjectName(QString::fromUtf8("welcome_lbl"));
        welcome_lbl->setMinimumSize(QSize(200, 30));
        welcome_lbl->setMaximumSize(QSize(300, 30));
        QFont font1;
        font1.setPointSize(14);
        font1.setBold(true);
        font1.setWeight(75);
        font1.setKerning(false);
        welcome_lbl->setFont(font1);
        welcome_lbl->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(welcome_lbl, 1, 3, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 6, 0, 1, 2);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 6, 4, 1, 1);

        start_btn = new QPushButton(centralwidget);
        start_btn->setObjectName(QString::fromUtf8("start_btn"));
        QSizePolicy sizePolicy1(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(start_btn->sizePolicy().hasHeightForWidth());
        start_btn->setSizePolicy(sizePolicy1);
        start_btn->setMinimumSize(QSize(200, 40));
        start_btn->setMaximumSize(QSize(200, 40));
        QFont font2;
        font2.setPointSize(10);
        font2.setBold(true);
        font2.setWeight(75);
        font2.setStrikeOut(false);
        start_btn->setFont(font2);
        start_btn->setFocusPolicy(Qt::ClickFocus);
        start_btn->setStyleSheet(QString::fromUtf8("background-color: rgb(225, 225, 225);\n"
""));
        start_btn->setAutoDefault(false);
        start_btn->setFlat(false);

        gridLayout->addWidget(start_btn, 6, 3, 1, 1);

        start_page->setCentralWidget(centralwidget);
        option_box->raise();
        start_pic_lbl->raise();
        caption_lbl->raise();
        welcome_lbl->raise();
        start_btn->raise();
        menubar = new QMenuBar(start_page);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 21));
        start_page->setMenuBar(menubar);
        statusbar = new QStatusBar(start_page);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        start_page->setStatusBar(statusbar);

        retranslateUi(start_page);
        QObject::connect(start_btn, SIGNAL(clicked()), start_page, SLOT(close()));

        light_combo->setCurrentIndex(0);
        language_combo->setCurrentIndex(0);
        start_btn->setDefault(true);


        QMetaObject::connectSlotsByName(start_page);
    } // setupUi

    void retranslateUi(QMainWindow *start_page)
    {
        start_page->setWindowTitle(QCoreApplication::translate("start_page", "Telegram", nullptr));
        caption_lbl->setText(QString());
        start_pic_lbl->setText(QString());
        light_combo->setItemText(0, QString());
        light_combo->setItemText(1, QString());

        language_combo->setItemText(0, QString());
        language_combo->setItemText(1, QString());

        welcome_lbl->setText(QString());
        start_btn->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class start_page: public Ui_start_page {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_START_PAGE_H
