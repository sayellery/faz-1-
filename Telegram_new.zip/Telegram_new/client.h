#ifndef CLIENT_H
#define CLIENT_H

#include <QObject>
#include <QTcpSocket>

class Client : public QObject
{
    Q_OBJECT
public:
    explicit Client(QObject *parent = nullptr);

signals:
    void connected();
    void disconnected();
    void error(QAbstractSocket::SocketError socketError);
    void messageReceived(QString message);

public slots:
    void connectToServer(QString ipAddress, int port);
    void disconnectFromServer();
    void sendMessage(QString message);

private slots:
    void receiveMessage();

private:
    QTcpSocket* socket;
};

#endif // CLIENT_H
