#include "chat_page.h"
#include "ui_chat_page.h"
#include "signup_page.h"
#include "start_page.h"
#include "globals.h"

#include "QToolBox"
#include "QMessageBox"

#include <QSqlDatabase>
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"



// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

chat_page::chat_page(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::chat_page)
{
    ui->setupUi(this);

    QSqlDatabase db ;
    db= QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\user_info.db");
    db.open();
    ui->user_edit_line->setText(global_username);
    ui->toolBox->setCurrentIndex(1);
    if(tm==0)                                              // تم روشن
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(255, 255, 255);");
    }
    if(tm==1)                                              // تم دارک
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(120, 120, 120);");
    }
    if(lng==0)                                             // زبان انگلیسی
    {
        ui->messege_line->setPlaceholderText("Message...");
        ui->user_edit_line->setPlaceholderText("Change Your Username");
        ui->name_edit_line->setPlaceholderText("Change Your Name");
        ui->pass_edit_line->setPlaceholderText("Change Your Password");
        ui->toolBox->setItemText(0 , "Setting");
        ui->toolBox->setItemText(1 , "Contacts");
        ui->light_combo->setItemText(0 , "Day Mode");
        ui->light_combo->setItemText(1 , "Night Mode");
        ui->language_combo->setItemText(0 , "English");
        ui->language_combo->setItemText(1 , "Persian");
        ui->delete_btn->setText("Delete Account");
        ui->contact_line->setPlaceholderText("Contact Username...");



    }
    if(lng==1)                                             // زبان فارسی
    {
        ui->messege_line->setPlaceholderText("پیام...");
        ui->user_edit_line->setPlaceholderText("نام کاربری خود را تغییر دهید");
        ui->name_edit_line->setPlaceholderText("نام خود را تغییر دهید");
        ui->pass_edit_line->setPlaceholderText("رمز عبور خود را تغییر دهید");
        ui->toolBox->setItemText(0 , "تنظیمات");
        ui->toolBox->setItemText(1 , "مخاطبین");
        ui->light_combo->setItemText(0 , "حالت شب");
        ui->light_combo->setItemText(1 , "حالت روز");
        ui->language_combo->setItemText(0 , "انگلیسی");
        ui->language_combo->setItemText(1 , "فارسی");
        ui->delete_btn->setText("حذف حساب کاربری");
        ui->contact_line->setPlaceholderText("نام کاربری مخاطب...");

    }
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

chat_page::~chat_page()
{
    delete ui;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void chat_page::on_light_combo_activated(int index)        // تنظیم تم برنامه
{
    if (index==0)
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(255, 255, 255);");
        tm=0;
    }
    else if (index==1)
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(120, 120, 120);");
        tm=1;
    }
}

void chat_page::on_language_combo_activated(int index)     // تنظیم زبان برنامه
{
    if (index==0)
    {
        ui->messege_line->setPlaceholderText("Message...");
        ui->user_edit_line->setPlaceholderText("Change Your Username");
        ui->name_edit_line->setPlaceholderText("Change Your Name");
        ui->pass_edit_line->setPlaceholderText("Change Your Password");
        ui->toolBox->setItemText(0 , "Setting");
        ui->toolBox->setItemText(1 , "Contacts");
        ui->light_combo->setItemText(0 , "Day Mode");
        ui->light_combo->setItemText(1 , "Night Mode");
        ui->language_combo->setItemText(0 , "English");
        ui->language_combo->setItemText(1 , "Persian");
        ui->delete_btn->setText("Delete Account");
        ui->contact_line->setPlaceholderText("Contact Username...");


        lng=0;
    }
    else if (index==1)
    {
        ui->messege_line->setPlaceholderText("پیام...");
        ui->user_edit_line->setPlaceholderText("نام کاربری خود را تغییر دهید");
        ui->name_edit_line->setPlaceholderText("نام خود را تغییر دهید");
        ui->pass_edit_line->setPlaceholderText("رمز عبور خود را تغییر دهید");
        ui->toolBox->setItemText(0 , "تنظیمات");
        ui->toolBox->setItemText(1 , "مخاطبین");
        ui->light_combo->setItemText(0 , "حالت روز");
        ui->light_combo->setItemText(1 , "حالت شب");
        ui->language_combo->setItemText(0 , "انگلیسی");
        ui->language_combo->setItemText(1 , "فارسی");
        ui->delete_btn->setText("حذف حساب کاربری");
        ui->contact_line->setPlaceholderText("نام کاربری مخاطب...");


        lng=1;
    }

}

void chat_page::on_delete_btn_clicked()                    // دیلیت اکانت
{
    QSqlQuery q;
    q.exec("DELETE FROM user WHERE username = '"+global_username+"' ");
    start_page *start = new start_page;
    start->show();
    this->~chat_page();
}

void chat_page::on_user_btn_clicked()                      // تغییر یوزرنیم
{
    QString username = ui->user_edit_line->text();
    QSqlQuery q;
    q.exec("SELECT username FROM user WHERE username= '"+username+"' ");

    if (username == "")                                    // خطا برای خالی بودن یوزرنیم
    {
        (lng == 1) ? QMessageBox::warning(this ," " ,"نام کاربری را وارد کنید" , "باشه") : QMessageBox::warning(this ,"" ,"Enter the username" , "OK");
    }
    else if (!signup_page::user_shart(username))           // خطا برای مناسب نبودن یوزرنیم
    {
        (lng == 1) ? QMessageBox::warning(this ," " ,"نام کاربری را اصلاح کنید" , "باشه") : QMessageBox::warning(this ,"" ,"Correct the username" , "OK");
    }
    else if (q.first())                                    // خطا برای تکراری بودن یوزرنیم
    {
        (lng == 1) ? QMessageBox::warning(this ," " ,"نام کاربری تکراری است" , "باشه") : QMessageBox::warning(this ,"" ,"Username already exists" , "OK");
    }
    else                                                   // تغییرات موفق
    {
        q.exec("UPDATE user SET username = '"+username+"' WHERE username = '"+global_username+"' ");
        global_username = username;
        (lng == 1) ? QMessageBox::information(this ," " ,"تغییرات ثبت شد" , "باشه") : QMessageBox::information(this ,"" ,"Changes were recorded" , "OK");

    }

}

void chat_page::on_name_btn_clicked()                      // تغییر نام
{
    QString name = ui->name_edit_line->text();
    QSqlQuery q;
    if (name == "")                                        // خطا برای خالی بودن نام
    {
        (lng == 1) ? QMessageBox::warning(this ," " ,"نام را وارد کنید" , "باشه") : QMessageBox::warning(this ,"" ,"Enter the name" , "OK");
    }

    else                                                   // تغییرات موفق
    {
        q.exec("UPDATE user SET name = '"+name+"' WHERE username = '"+global_username+"' ");
        (lng == 1) ? QMessageBox::information(this ," " ,"تغییرات ثبت شد" , "باشه") : QMessageBox::information(this ,"" ,"Changes were recorded" , "OK");

    }
}

void chat_page::on_pass_btn_clicked()                      // تغییر پسورد
{
    QString password = ui->pass_edit_line->text();
    QSqlQuery q;
    if (password == "")                                    // خطا برای خالی بودن پسورد
    {
        (lng == 1) ? QMessageBox::warning(this ," " ,"نام کاربری را وارد کنید" , "باشه") : QMessageBox::warning(this ,"" ,"Enter the username" , "OK");
    }
    else if (!signup_page::pass_shart(password))           // خطا برای مناسب نبودن پسورد
    {
        (lng == 1) ? QMessageBox::warning(this ," " ,"نام کاربری را اصلاح کنید" , "باشه") : QMessageBox::warning(this ,"" ,"Correct the username" , "OK");
    }
    else                                                   // تغییرات موفق
    {
        q.exec("UPDATE user SET password = '"+password+"' WHERE username = '"+global_username+"' ");
        (lng == 1) ? QMessageBox::information(this ," " ,"تغییرات ثبت شد" , "باشه") : QMessageBox::information(this ,"" ,"Changes were recorded" , "OK");

    }

}

void chat_page::on_contact_btn_clicked()                   // اضافه کردن مخاطب
{
    QString contact_username = ui->contact_line->text();
    QSqlQuery q;
    q.exec("SELECT username FROM user WHERE username = '"+contact_username+"' ");
    if(!q.first())                                         //مخاطب موجود نیست
    {
        (lng == 1) ? QMessageBox::warning(this ," " ,"کاربر یافت نشد" , "باشه") : QMessageBox::warning(this ,"" ,"User Not Founf" , "OK");

    }
    else                                                   // مخاطب موجود است و به لیست مخاطبین اضافه می شود
    {


    }
}
