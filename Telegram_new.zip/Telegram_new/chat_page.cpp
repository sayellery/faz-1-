#include "chat_page.h"
#include "ui_chat_page.h"
#include "globals.h"


// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

chat_page::chat_page(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::chat_page)
{
    ui->setupUi(this);
    if(tm==0)                                              // تم روشن
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(255, 255, 255);");
    }
    if(tm==1)                                              // تم دارک
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(120, 120, 120);");
    }

}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

chat_page::~chat_page()
{
    delete ui;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
