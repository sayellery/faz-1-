#include "name_page.h"
#include "ui_name_page.h"
#include "chat_page.h"
#include "globals.h"
#include <QMessageBox>

//extern MyQSqlDatabase db ;
extern QString NewUserName ;
QString Name ;
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

name_page::name_page(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::name_page)
{
    ui->setupUi(this);
    if(tm==0)                                              // تم روشن
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(255, 255, 255);");
    }
    if(tm==1)                                              // تم دارک
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(120, 120, 120);");
    }
    if(lng==0)                                             // زبان انگلیسی
    {
        ui->name_line->setPlaceholderText("Enter Your Name");
        ui->name_btn->setText("Confirm");
        ui->back_btn->setText("Back");
    }
    if(lng==1)                                             // زبان فارسی
    {
        ui->name_line->setPlaceholderText("نام خود را وارد کنید");
        ui->name_btn->setText("تایید");
        ui->back_btn->setText("عقب");
    }

}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

name_page::~name_page()
{
    delete ui;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void name_page::on_name_btn_clicked()
{
    if (ui->name_line->text()=="")
        (lng==1) ? QMessageBox::warning(this ," " ,"نام خود را وارد کنید" , "باشه") : QMessageBox::warning(this ,"" ,"Enter Your Name" , "OK");
    else
    {
        //db.Insert_name( NewUserName , ui->name_line->text() ) ;
        Name = ui->name_line->text();
        (lng==1) ? QMessageBox::warning(this ," " ,"خوش آمدید" , "شروع") : QMessageBox::warning(this ,"" ,"Wellcome" , "Start");

        chat_page *chat = new chat_page () ;
        chat->show() ;
        this->close() ;
        this->~name_page() ;
    }
}
