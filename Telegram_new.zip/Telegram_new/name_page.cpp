#include "name_page.h"
#include "ui_name_page.h"
#include "chat_page.h"
#include "signup_page.h"
#include "globals.h"

#include "QMessageBox"

#include <QSqlDatabase>
#include "QSqlDriver"
#include "QSqlQuery"
#include "QSqlQueryModel"
// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

name_page::name_page(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::name_page)
{
    ui->setupUi(this);

    QSqlDatabase db ;
    db= QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("d:\\user_info.db");
    db.open();

    if(tm==0)                                              // تم روشن
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(255, 255, 255);");
    }
    if(tm==1)                                              // تم دارک
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(120, 120, 120);");
    }
    if(lng==0)                                             // زبان انگلیسی
    {
        ui->name_line->setPlaceholderText("Enter Your Name");
        ui->name_btn->setText("Confirm");
        ui->back_btn->setText("Back");

    }
    if(lng==1)                                             // زبان فارسی
    {
        ui->name_line->setPlaceholderText("نام خود را وارد کنید");
        ui->name_btn->setText("تایید");
        ui->back_btn->setText("عقب");
    }

}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

name_page::~name_page()
{
    delete ui;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void name_page::on_name_btn_clicked()                      // ذخیره نام و رفتن به صفحه چت
{
    QSqlQuery q;
    QString name;
     name = ui->name_line->text();

    if (name=="")                                          // خطا برای خالی بودن نام
    {(lng==1) ? QMessageBox::warning(this ," " ,"نام خود را وارد کنید" , "باشه") : QMessageBox::warning(this ,"" ,"Enter Your Name" , "OK");}
    else                                                   // ذخیره نام در دیتابیس
    {

        q.exec("UPDATE user SET name = '"+name+"' WHERE username = '"+global_username+"' ");
        chat_page *chat = new chat_page () ;
        chat->show() ;
        this->close() ;
    }
}

void name_page::on_back_btn_clicked()                      // بازگشت به صفحه قبلی و بستن صفحه فعلی
{
    signup_page *sign = new signup_page;
    sign->show();
    this->~name_page();
}
