#ifndef GLOBALS_H
#define GLOBALS_H

extern bool lng;
extern bool tm;
#endif // GLOBALS_H
