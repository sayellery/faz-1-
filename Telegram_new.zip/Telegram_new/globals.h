#ifndef GLOBALS_H
#define GLOBALS_H
#include "QString"

extern bool lng;
extern bool tm;
extern QString global_username;

#endif // GLOBALS_H
