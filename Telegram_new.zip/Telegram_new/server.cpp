#include "server.h"

Server::Server(QObject *parent) : QTcpServer(parent)
{
}

void Server::startServer()
{
    if(!this->listen(QHostAddress::Any, 1234))
    {
        qDebug() << "Could not start server";
    }
    else
    {
        qDebug() << "Server started";
    }
}

void Server::incomingConnection(qintptr socketDescriptor)
{
    QTcpSocket* socket = new QTcpSocket(this);
    socket->setSocketDescriptor(socketDescriptor);

    connect(socket, SIGNAL(readyRead()), this, SLOT(receiveMessage()));

    clientSockets.append(socket);

    qDebug() << "Client connected:" << socketDescriptor;
}

void Server::receiveMessage()
{
    QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());

    if(socket == nullptr)
        return;

    QByteArray data = socket->readAll();
    QString message(data);

    qDebug() << "Received message:" << message;

    emit messageReceived(message);
}
