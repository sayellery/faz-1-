#ifndef SERVER_H
#define SERVER_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>

class Server : public QTcpServer
{
    Q_OBJECT
public:
    explicit Server(QObject *parent = nullptr);

signals:
    void messageReceived(QString message);

public slots:
    void startServer();
    void incomingConnection(qintptr socketDescriptor);
    void receiveMessage();

private:
    QList<QTcpSocket*> clientSockets;
};

#endif // SERVER_H
