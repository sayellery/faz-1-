#ifndef CHAT_PAGE_H
#define CHAT_PAGE_H

#include <QMainWindow>

namespace Ui {
class chat_page;
}

class chat_page : public QMainWindow
{
    Q_OBJECT

public:
    explicit chat_page(QWidget *parent = nullptr);
    ~chat_page();

private:
    Ui::chat_page *ui;
};

#endif // CHAT_PAGE_H
