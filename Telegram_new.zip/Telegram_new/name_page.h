#ifndef NAME_PAGE_H
#define NAME_PAGE_H

#include <QMainWindow>

namespace Ui {
class name_page;
}

class name_page : public QMainWindow
{
    Q_OBJECT

public:
    explicit name_page(QWidget *parent = nullptr);
    ~name_page();

private slots:
    void on_name_btn_clicked();

    void on_back_btn_clicked();

private:
    Ui::name_page *ui;
};

#endif // NAME_PAGE_H
