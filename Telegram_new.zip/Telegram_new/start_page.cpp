#include "start_page.h"
#include "ui_start_page.h"
#include "signup_page.h"
#include "globals.h"

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

start_page::start_page(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::start_page)
{

    ui->setupUi(this);
    ui->light_combo->QComboBox::activated(0);                          // تم پیشفرض روشن باشه
    ui->language_combo->QComboBox::activated(0);                       // زبان پیشفرض انگلیسی باشه

}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

start_page::~start_page()
{
    delete ui;
}

// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void start_page::on_light_combo_activated(int index) // تنظیم تم برنامه
{

    if(index==0)    // تم روشن
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(255, 255, 255);");
        tm=0;

    }
    if(index==1)    // تم دارک
    {
        ui->centralwidget->setStyleSheet("background-color: rgb(120, 120, 120);");
        tm=1;
    }
}

void start_page::on_language_combo_activated(int index) //تنظیم زبان برنامه
{

    if(index==0)    // زبان انگلیسی
    {
        ui->welcome_lbl->setText("Welcome To Telegram");
        ui->caption_lbl->setText("Free . Unlimited . Fast");
        ui->start_btn->setText("Start Messaging");
        ui->light_combo->setItemText(0 , "Light");
        ui->light_combo->setItemText(1 , "Dark");
        lng=0;

    }
    if(index==1)    // زبان فارسی
    {
        ui->welcome_lbl->setText("به تلگرام خوش آمدید");
        ui->caption_lbl->setText("رایگان . نامحدود . سریع");
        ui->start_btn->setText("شروع پیامرسانی");
        ui->light_combo->setItemText(0 , "حالت روز");
        ui->light_combo->setItemText(1 , "حالت شب");
        lng=1;
    }
}

void start_page::on_start_btn_clicked() // بستن صفحه استارت و رفتن به صفحه ثبت نام
{
    signup_page *sign = new signup_page;
    sign->show();

}
