#ifndef START_PAGE_H
#define START_PAGE_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class start_page; }
QT_END_NAMESPACE

class start_page : public QMainWindow
{
    Q_OBJECT

public:
    start_page(QWidget *parent = nullptr);
    ~start_page();


public slots:

    void on_light_combo_activated(int index);

    void on_language_combo_activated(int index);

    void on_start_btn_clicked();

private:
    Ui::start_page *ui;
};
#endif // START_PAGE_H
